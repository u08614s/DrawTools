#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#define DATA_BUFFER_SIZE 0x5000

void startTCPGecko(void);

#ifdef __cplusplus
}
#endif